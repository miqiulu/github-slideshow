/lesson-1/       /lesson-1-up-and-running-python/README
/lesson-2/       /lesson-2-collection-and-logic-flow/README
/lesson-3/       /lesson-3-reading-writing-text-file/README
/lesson-4/       /lesson-4-divide-and-conquer/README
/lesson-5/       /lesson-5-url-and-api/README
/lesson-6/       /lesson-6-web-scrapping/README
/lesson-7/       /lesson-7-web-automation-with-selenium/README
/lesson-8/       /lesson-8-numpy-and-pandas/README
/lesson-9/       /lesson-9-plotting-graph-with-matplotlib/README
/lesson-10/      /lesson-10-bringing-python-to-life/README



/lesson-1-up-and-running-python/               /lesson-1-up-and-running-python/README
/lesson-2-collection-and-logic-flow/           /lesson-2-collection-and-logic-flow/README
/lesson-3-reading-writing-text-file/           /lesson-3-reading-writing-text-file/README
/lesson-4-divide-and-conquer/                  /lesson-4-divide-and-conquer/README
/lesson-5-url-and-api/                         /lesson-5-url-and-api/README
/lesson-6-web-scrapping/                       /lesson-6-web-scrapping/README
/lesson-7-web-automation-with-selenium/        /lesson-7-web-automation-with-selenium/README
/lesson-8-numpy-and-pandas/                    /lesson-8-numpy-and-pandas/README
/lesson-9-plotting-graph-with-matplotlib/      /lesson-9-plotting-graph-with-matplotlib/README
/lesson-10-bringing-python-to-life/            /lesson-10-bringing-python-to-life/README