---
layout: layout
title: Beginning Python Course
---

[→ Enroll into the course](/README/)


## This course is in early stage

This course is currently in early stage drafting. The content is now a dump of my static-site in-person course. Please expect a complete re-writing for all content.