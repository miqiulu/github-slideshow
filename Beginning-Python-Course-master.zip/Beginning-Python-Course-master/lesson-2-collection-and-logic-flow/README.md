---
title: Lesson 2—Collection and Logic flow
prev: /lesson-1
next: /lesson-3
layout: lesson
---

In this lesson, we learn to store a collection of values by using list, tuple, dictionary, and Named Tuple. We also learn to control the logic flow. We will use if, while, for to create condition and iteration.