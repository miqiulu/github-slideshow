---
title: Lesson 6
prev: /lesson-5
next: /lesson-7
layout: lesson
---

This is 2/3 of the web scraping series.

In this lesson, we will learn to extract data from the web page by downloading the HTML page and parse the HTML element tree into structural data.



## robots.txt


## Installing BeautifulSoup and HTML parser

```
pip install requests
pip install bs4
```


## Using BeautifulSoup


Example of fetching news heading.

```python
```